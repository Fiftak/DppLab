

print("INIT Lib1")