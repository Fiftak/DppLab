

print("INIT Lib2")