from enum import Enum

def printFileName():
    print("Uroczystosc")

class Uroczystosc(Enum):
    Kolacja=1,
    Impreza_Domowa=2,
    Wesele=3,
    Uroczysty_Obiad=4,
    Gril=5
