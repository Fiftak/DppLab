

print("INIT Lib3")